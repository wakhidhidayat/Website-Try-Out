<html>
@if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
<head>

<meta http-equiv=Content-Type content="text/html; charset=windows-1252">
<meta name=Generator content="Microsoft Word 15 (filtered)">
<style>
<!--
 /* Font Definitions */
 @font-face
	{font-family:Wingdings;
	panose-1:5 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:"Cambria Math";
	panose-1:2 4 5 3 5 4 6 3 2 4;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
@font-face
	{font-family:"Roboto Lt";
	panose-1:0 0 0 0 0 0 0 0 0 0;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin-top:0cm;
	margin-right:0cm;
	margin-bottom:8.0pt;
	margin-left:0cm;
	line-height:107%;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;}
p.MsoListParagraph, li.MsoListParagraph, div.MsoListParagraph
	{margin-top:0cm;
	margin-right:0cm;
	margin-bottom:8.0pt;
	margin-left:36.0pt;
	line-height:107%;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;}
p.MsoListParagraphCxSpFirst, li.MsoListParagraphCxSpFirst, div.MsoListParagraphCxSpFirst
	{margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:36.0pt;
	margin-bottom:.0001pt;
	line-height:107%;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;}
p.MsoListParagraphCxSpMiddle, li.MsoListParagraphCxSpMiddle, div.MsoListParagraphCxSpMiddle
	{margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:36.0pt;
	margin-bottom:.0001pt;
	line-height:107%;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;}
p.MsoListParagraphCxSpLast, li.MsoListParagraphCxSpLast, div.MsoListParagraphCxSpLast
	{margin-top:0cm;
	margin-right:0cm;
	margin-bottom:8.0pt;
	margin-left:36.0pt;
	line-height:107%;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;}
.MsoChpDefault
	{font-family:"Calibri",sans-serif;}
.MsoPapDefault
	{margin-bottom:8.0pt;
	line-height:107%;}
@page WordSection1
	{size:728.5pt 1031.8pt;
	margin:72.0pt 72.0pt 72.0pt 72.0pt;}
div.WordSection1
	{page:WordSection1;}
 /* List Definitions */
 ol
	{margin-bottom:0cm;}
ul
	{margin-bottom:0cm;}
-->
</style>

</head>

<body lang=EN-ID>

<div class=WordSection1>

<p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt'><img
width=158 height=158 src="{{ asset('images/image001.jpg') }}"
align=left hspace=12><b><span style='font-size:36.0pt;line-height:107%'>KARTU
TANDA PESERTA</span></b></p>

<p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt'><span
style='font-size:20.0pt;line-height:107%'>TRY OUT SBMPTN 5<sup>TH</sup> GADJAH
MADA</span></p>

<p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt'><span
style='font-size:20.0pt;line-height:107%'>EVENT IN BEKASI</span></p>

<p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt'><span
style='font-size:20.0pt;line-height:107%'>__________________________________________________________</span></p>

<p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt'><span
style='font-size:20.0pt;line-height:107%'>&nbsp;</span></p>

<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none'>
 <tr>
  <td width=283 valign=top style='width:212.4pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  115%'><span style='font-size:18.0pt;line-height:115%;font-family:"Roboto Lt"'>Nomor
  Ujian</span></p>
  </td>
  <td width=495 valign=top style='width:371.6pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  115%'><span style='font-size:18.0pt;line-height:115%;font-family:"Roboto Lt"'>:
  10231</span></p>
  </td>
 </tr>
 <tr>
  <td width=283 valign=top style='width:212.4pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  115%'><span style='font-size:18.0pt;line-height:115%;font-family:"Roboto Lt"'>Nama
  Peserta</span></p>
  </td>
  <td width=495 valign=top style='width:371.6pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  115%'><span style='font-size:18.0pt;line-height:115%;font-family:"Roboto Lt"'>:
  Menara Lintang</span></p>
  </td>
 </tr>
 <tr>
  <td width=283 valign=top style='width:212.4pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  115%'><span style='font-size:18.0pt;line-height:115%;font-family:"Roboto Lt"'>Tanggal
  Lahir</span></p>
  </td>
  <td width=495 valign=top style='width:371.6pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  115%'><span style='font-size:18.0pt;line-height:115%;font-family:"Roboto Lt"'>:
  08/08/09</span></p>
  </td>
 </tr>
 <tr>
  <td width=283 valign=top style='width:212.4pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  115%'><span style='font-size:18.0pt;line-height:115%;font-family:"Roboto Lt"'>No.
  Handphone</span></p>
  </td>
  <td width=495 valign=top style='width:371.6pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  115%'><span style='font-size:18.0pt;line-height:115%;font-family:"Roboto Lt"'>:
  08979</span></p>
  </td>
 </tr>
 <tr>
  <td width=283 valign=top style='width:212.4pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  115%'><span style='font-size:18.0pt;line-height:115%;font-family:"Roboto Lt"'>Alamat</span></p>
  </td>
  <td width=495 valign=top style='width:371.6pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  115%'><span style='font-size:18.0pt;line-height:115%;font-family:"Roboto Lt"'>:
  Kanggotan</span></p>
  </td>
 </tr>
 <tr>
  <td width=283 valign=top style='width:212.4pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  115%'><span style='font-size:18.0pt;line-height:115%;font-family:"Roboto Lt"'>Asal
  Sekolah</span></p>
  </td>
  <td width=495 valign=top style='width:371.6pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  115%'><span style='font-size:18.0pt;line-height:115%;font-family:"Roboto Lt"'>:
  SMK 1 PARIWISATA</span></p>
  </td>
 </tr>
 <tr>
  <td width=283 valign=top style='width:212.4pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  115%'><span style='font-size:18.0pt;line-height:115%;font-family:"Roboto Lt"'>Email
  </span></p>
  </td>
  <td width=495 valign=top style='width:371.6pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  115%'><span style='font-size:18.0pt;line-height:115%;font-family:"Roboto Lt"'>:
  asfasf@daf</span></p>
  </td>
 </tr>
 <tr>
  <td width=283 valign=top style='width:212.4pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  115%'><span style='font-size:18.0pt;line-height:115%;font-family:"Roboto Lt"'>Kelompok
  Ujian</span></p>
  </td>
  <td width=495 valign=top style='width:371.6pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  115%'><span style='font-size:18.0pt;line-height:115%;font-family:"Roboto Lt"'>:
  SAINTEK</span></p>
  </td>
 </tr>
</table>

<p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt'><span
style='font-size:20.0pt;line-height:107%'>&nbsp;</span></p>

<table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none'>
 <tr style='height:156.6pt'>
  <td width=567 valign=top style='width:425.0pt;border:solid windowtext 1.0pt;
  background:#E2EFD9;padding:0cm 5.4pt 0cm 5.4pt;height:156.6pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal'><span style='font-size:12.0pt'>Catatan :</span></p>
  <p class=MsoListParagraphCxSpFirst style='margin-bottom:0cm;margin-bottom:
  .0001pt;text-indent:-18.0pt;line-height:normal'><span style='font-size:12.0pt;
  font-family:Symbol'>·<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  </span></span><span style='font-size:12.0pt;color:black'>Datang 30 menit
  sebelum dimulai Acara</span></p>
  <p class=MsoListParagraphCxSpMiddle style='margin-bottom:0cm;margin-bottom:
  .0001pt;text-indent:-18.0pt;line-height:normal'><span style='font-size:12.0pt;
  font-family:Symbol'>·<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  </span></span><span style='font-size:12.0pt;color:black'>Membawa Kartu Tanda Peserta
  ini</span></p>
  <p class=MsoListParagraphCxSpLast style='margin-bottom:0cm;margin-bottom:
  .0001pt;text-indent:-18.0pt;line-height:normal'><span style='font-size:12.0pt;
  font-family:Symbol'>·<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  </span></span><span style='font-size:12.0pt;color:black'>Menaati Tata Tertib
  Ujian</span></p>
  </td>
  <td width=212 valign=top style='width:159.0pt;border:solid windowtext 1.0pt;
  border-left:none;padding:0cm 5.4pt 0cm 5.4pt;height:156.6pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal'><span style='font-size:12.0pt'><img width=201 height=201
  id="Picture 2" src="{{ asset('images/image002.png') }}"></span></p>
  </td>
 </tr>
</table>

<p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt'><span
style='font-size:20.0pt;line-height:107%'>&nbsp;</span></p>

</div>

</body>

</html>
