<?php $__env->startSection('title'); ?>
    Admin Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.index')); ?>">
        <div class="row">
            <div class="col-md-6">
                <input
                value="<?php echo e(Request::get('q')); ?>"
                name="q"
                class="form-control col-md-10"
                type="text"
                placeholder="Cari berdasarkan nama"/>
            </div>
            <div class="col-md-6">
                <input <?php echo e(Request::get('status') == 'VERIFIED' ? 'checked' : ''); ?>

                value="VERIFIED"
                name="status"
                type="radio"
                class="form-control"
                id="verified">
                <label for="verified">Verified</label>

                <input <?php echo e(Request::get('status') != 'VERIFIED' ? 'checked' : ''); ?>

                value="MENUNGGU PEMBAYARAN"
                name="status"
                type="radio"
                class="form-control"
                id="menunggu-pembayaran">
                <label for="menunggu-pembayaran">Menunggu Pembayaran</label>

                <input
                type="submit"
                value="Filter Peserta"
                class="btn btn-primary">
            </div>
        </div>
    </form> <br>

    <table class="table table-bordered">
        <thead>
            <tr>
                <td><b>No</b></td>
                <td><b>Nama</b></td>
                <td><b>Email</b></td>
                <td><b>No Peserta</b></td>
                <td><b>Kelas</b></td>
                <td><b>No HP</b></td>
                <td><b>Alamat</b></td>
                <td><b>Tanggal lahir</b></td>
                <td><b>Kelompok</b></td>
                <td><b>Asal Sekolah</b></td>
                <td><b>Status</b></td>
                <td><b>Edit</b></td>
                <td><b>Delete</b></td>
                <td><b>Bukti Bayar</b></td>
                <td><b>Verifikasi</b></td>

            </tr>
        </thead>
        <tbody>
            <?php
                $no = 1;
            ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($user->role == "USER"): ?>
                   <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($user->nama); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->no_ujian); ?></td>
                    <td><?php echo e($user->kelas); ?></td>
                    <td><?php echo e($user->no_hp); ?></td>
                    <td><?php echo e($user->alamat); ?></td>
                    <td><?php echo e($user->tgl_lahir); ?></td>
                    <td><?php echo e($user->kelompok); ?></td>
                    <td><?php echo e($user->asal_sekolah); ?></td>
                    <td>
                        <?php if($user->status == "VERIFIED"): ?>
                            <span class="badge badge-success">
                                <?php echo e($user->status); ?>

                            </span>
                        <?php else: ?>
                            <span class="badge badge-danger">
                                <?php echo e($user->status); ?>

                            </span>
                        <?php endif; ?>
                    </td>
                    <td><a class="btn btn-info text-white btn-sm" href="<?php echo e(route('admin.edit',['id'=>$user->id])); ?>">Edit</a></td>
                    <td>
                        <form
                        onsubmit="return confirm('Hapus Peserta Ini?')"
                        class="d-inline"
                        action="<?php echo e(route('admin.destroy', ['id' => $user->id ])); ?>"
                        method="POST">
                        <?php echo csrf_field(); ?>
                        <input
                        type="hidden"
                        name="_method"
                        value="DELETE">
                        <input
                        type="submit"
                        value="Delete"
                        class="btn btn-danger btn-sm">
                        </form>
                    </td>
                    <?php if($user->bukti_bayar != null): ?>
                    <td>
                        <a href="<?php echo e(asset('storage/'.$user->bukti_bayar)); ?>" class="btn btn-primary">Lihat Bukti Bayar</a>
                    </td>
                    <?php else: ?>
                        <td>Belum Ada</td>
                    <?php endif; ?>

                        <?php if($user->status != "VERIFIED"): ?>
                        <td>
                            <form
                            onsubmit="return confirm('Verifikasi Peserta Ini?')"
                            class="d-inline"
                            action="<?php echo e(route('admin.verif', ['id' => $user->id ])); ?>"
                            method="POST">
                            <?php echo csrf_field(); ?>
                            <input
                            type="hidden"
                            name="_method"
                            value="PUT">
                            <input
                            type="submit"
                            value="Verifikasi"
                            class="btn btn-success btn-sm">
                            </form>
                        </td>
                        <?php else: ?>
                        <td>
                            <a href="<?php echo e(route('admin.print', ['id' => $user->id])); ?>" class="btn btn-success">Cetak Kartu</a>
                        </td>

                        <?php endif; ?>
                    </td>
                </tr>

                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan=10>
                    <?php echo e($users->appends(Request::all())->links()); ?>

                </td>
            </tr>
        </tfoot>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>