<?php $__env->startSection('title'); ?>
    Edit Peserta
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-8">
    <form enctype="multipart/form-data" class="bg-white shadow-sm p-3" action="<?php echo e(route('admin.update', ['id'=>$user->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" value="PUT" name="_method">

        <label for="nama">Nama</label>
        <input type="text" name="nama" value="<?php echo e($user->nama); ?>" class="form-control" placeholder="Nama Lengkap">
        <label for="alamat">Alamat</label>
        <input type="text" name="alamat" value="<?php echo e($user->alamat); ?>" class="form-control" placeholder="Alamat">
        <label for="no_hp">No Hp</label>
        <input type="text" name="no_hp" value="<?php echo e($user->no_hp); ?>" class="form-control" placeholder="Nomor Hp" maxlength="20">
        <label for="kelompok">Kelompok</label>
        <select name="kelompok" class="form-control">
            <option value="SAINTEK" <?php echo e($user->kelompok == 'SAINTEK' ? 'selected' : ''); ?>>SAINTEK</option>
            <option value="SOSHUM" <?php echo e($user->kelompok == 'SOSHUM' ? 'selected' : ''); ?>>SOSHUM</option>
        </select>
        <label for="asal_sekolah">Asal Sekolah</label>
        <input type="text" name="asal_sekolah" value="<?php echo e($user->asal_sekolah); ?>" class="form-control" placeholder="Asal Sekolah">
        <label for="status">Status Peserta</label>
        <select name="status" class="form-control">
            <option value="MENUNGGU PEMBAYARAN" <?php echo e($user->status == 'MENUNGGU PEMBAYARAN' ? 'selected' : ''); ?>>Menunggu Pembayaran</option>
            <option value="VERIFIED" <?php echo e($user->status == 'VERIFIED' ? 'selected' : ''); ?>>Terverifikasi</option>
        </select>
        <br>
        <input type="submit" class="btn btn-primary" value="Update Data">
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>