<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard Peserta</div>
                <div class="card-body">
                    <!-- <div>
                        <img src="<?php echo e(asset('storage/'.Auth::user()->foto_url)); ?>"  class="rounded img-fluid img-thumbnail" alt="photo profile" >
                    </div> -->
                    <form>
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label for="nama" class="col-md-4 col-form-label text-md-right"><?php echo e(__('No Pendaftaran')); ?></label>
                            <div class="col-md-6">
                                <input id="nama" type="text" class="form-control" name="nama" value="<?php echo e(Auth::user()->no_ujian); ?>" disabled>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="nama" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nama')); ?></label>

                            <div class="col-md-6">
                                <input id="nama" type="text" class="form-control" name="nama" value="<?php echo e(Auth::user()->nama); ?>" disabled>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Tanggal Lahir')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="tgl_lahir" value=" <?php echo e(Auth::user()->tgl_lahir); ?>" disabled>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('No Hp')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="no_hp" value=" <?php echo e(Auth::user()->no_hp); ?>" disabled>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Kelompok')); ?></label>
                            <div class="col-md-6">
                                <select name="kelompok" id="name" class="form-control" disabled>
                                    <option value=" <?php echo e(Auth::user()->kelompok); ?>"> <?php echo e(Auth::user()->kelompok); ?></option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Alamat')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="textarea" class="form-control" name="alamat" value=" <?php echo e(Auth::user()->alamat); ?>" disabled>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Asal Sekolah')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="asal_sekolah" value=" <?php echo e(Auth::user()->asal_sekolah); ?>" disabled>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>
                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value=" <?php echo e(Auth::user()->email); ?>" disabled>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Status Peserta')); ?></label>
                            <div class="col-md-6">
                                <?php if(Auth::user()->status == "VERIFIED"): ?>
                                    <div class="alert alert-success" role="alert">
                                        <?php echo e(Auth::user()->status); ?>

                                    </div>
                                    <div class="text-center justify-content-center">
                                        <?php echo QrCode::size(250)->generate(\Auth::user()->no_ujian);; ?>

                                        <a href="<?php echo e(route('print')); ?>" class="col btn btn-lg btn-primary">Cetak Kartu</a>
                                    </div>
                                <?php else: ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php echo e(Auth::user()->status); ?>

                                    </div>
                                    <div>
                                        Pembayaran dilakukan dengan transfer ke nomor rekening :
                                        <b> <br> BCA : 8850813354
                                        <br> BNI : 0887207347
                                        <br> </b>Atas Nama : <b>Apresia Dwiyunita</b>
                                        <br> Silakan Upload Bukti Pembayaran untuk <b>Verifikasi
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>
                    <?php if(Auth::user()->status != "VERIFIED"): ?>
                        <form action="" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <label for="bukti_bayar" class="col-md-4 col-form-label text-md-right"></label>
                                <div class="col-md-6">
                                    <input type="file" name="bukti_bayar" id="bukti_bayar">
                                </div>
                            </div>
                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        Upload
                                    </button>
                                </div>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>